// Initialize PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.338/pdf.worker.min.js';

let pdfDoc = null;
let selectedPages = new Set();
const PAGE_RENDER_SIZE = 300; // Width in pixels

// DOM elements
const fileInput = document.getElementById('pdf-file');
const previewContainer = document.getElementById('pdf-preview');
const statusEl = document.getElementById('status');

// Event listeners
fileInput.addEventListener('change', handleFileUpload);
document.getElementById('split-btn').addEventListener('click', splitPDF);
document.getElementById('download-btn').addEventListener('click', downloadSplitPDF);
document.getElementById('select-all').addEventListener('click', () => selectAllPages(true));
document.getElementById('select-odd').addEventListener('click', selectOddPages);
document.getElementById('select-even').addEventListener('click', selectEvenPages);
document.getElementById('select-range').addEventListener('click', selectPageRange);

// Handle PDF upload
async function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    statusEl.textContent = "Loading PDF...";
    previewContainer.innerHTML = '';
    selectedPages.clear();

    try {
        const arrayBuffer = await file.arrayBuffer();
        pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
        
        // Create loading placeholder
        previewContainer.innerHTML = 
            `<div class="loading">Rendering ${pdfDoc.numPages} pages...</div>`;
        
        // Render pages progressively
        renderPagesInBatches(pdfDoc);
        
    } catch (error) {
        statusEl.textContent = "Error loading PDF: " + error.message;
    }
}

// Render pages in batches for performance
async function renderPagesInBatches(pdfDoc) {
    const batchSize = 5;
    let renderedPages = 0;
    
    for (let i = 1; i <= pdfDoc.numPages; i++) {
        try {
            const page = await pdfDoc.getPage(i);
            const viewport = page.getViewport({ scale: PAGE_RENDER_SIZE / page.getViewport({ scale: 1 }).width });
            
            const thumbnail = document.createElement('div');
            thumbnail.className = 'page-thumbnail';
            thumbnail.style.width = `${viewport.width}px`;
            
            const canvas = document.createElement('canvas');
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            canvas.dataset.pageNum = i;
            
            const pageNum = document.createElement('div');
            pageNum.className = 'page-number';
            pageNum.textContent = `Page ${i}`;
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'page-checkbox';
            checkbox.dataset.page = i;
            checkbox.addEventListener('change', togglePageSelection);
            
            thumbnail.appendChild(checkbox);
            thumbnail.appendChild(pageNum);
            thumbnail.appendChild(canvas);
            previewContainer.appendChild(thumbnail);
            
            // Render page content
            await page.render({
                canvasContext: canvas.getContext('2d'),
                viewport: viewport
            }).promise;
            
            renderedPages++;
            
            // Update status periodically
            if (i % batchSize === 0 || i === pdfDoc.numPages) {
                statusEl.textContent = `Rendered ${renderedPages}/${pdfDoc.numPages} pages...`;
                // Small delay to allow UI to update
                await new Promise(resolve => setTimeout(resolve, 50));
            }
            
        } catch (error) {
            console.error(`Error rendering page ${i}:`, error);
        }
    }
    
    statusEl.textContent = `Ready! ${pdfDoc.numPages} pages loaded. Select pages to split.`;
    updateDownloadButton();
}

// Selection functions
function togglePageSelection(e) {
    const pageNum = parseInt(e.target.dataset.page);
    if (e.target.checked) {
        selectedPages.add(pageNum);
    } else {
        selectedPages.delete(pageNum);
    }
    updateDownloadButton();
}

function selectAllPages(select = true) {
    const checkboxes = document.querySelectorAll('.page-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = select;
        const pageNum = parseInt(checkbox.dataset.page);
        if (select) {
            selectedPages.add(pageNum);
        } else {
            selectedPages.delete(pageNum);
        }
    });
    updateDownloadButton();
}

function selectOddPages() {
    const checkboxes = document.querySelectorAll('.page-checkbox');
    checkboxes.forEach(checkbox => {
        const pageNum = parseInt(checkbox.dataset.page);
        const isOdd = pageNum % 2 === 1;
        checkbox.checked = isOdd;
        if (isOdd) {
            selectedPages.add(pageNum);
        } else {
            selectedPages.delete(pageNum);
        }
    });
    updateDownloadButton();
}

function selectEvenPages() {
    const checkboxes = document.querySelectorAll('.page-checkbox');
    checkboxes.forEach(checkbox => {
        const pageNum = parseInt(checkbox.dataset.page);
        const isEven = pageNum % 2 === 0;
        checkbox.checked = isEven;
        if (isEven) {
            selectedPages.add(pageNum);
        } else {
            selectedPages.delete(pageNum);
        }
    });
    updateDownloadButton();
}

function selectPageRange() {
    const start = parseInt(document.getElementById('range-start').value) || 1;
    const end = parseInt(document.getElementById('range-end').value) || pdfDoc.numPages;
    
    const checkboxes = document.querySelectorAll('.page-checkbox');
    checkboxes.forEach(checkbox => {
        const pageNum = parseInt(checkbox.dataset.page);
        const inRange = pageNum >= start && pageNum <= end;
        checkbox.checked = inRange;
        if (inRange) {
            selectedPages.add(pageNum);
        } else {
            selectedPages.delete(pageNum);
        }
    });
    updateDownloadButton();
}

function updateDownloadButton() {
    document.getElementById('download-btn').disabled = selectedPages.size === 0;
}

// PDF Processing
async function splitPDF() {
    if (!pdfDoc || selectedPages.size === 0) {
        alert("Please select at least 1 page to extract!");
        return;
    }

    statusEl.textContent = "Processing PDF...";
    
    try {
        const { PDFDocument } = PDFLib;
        const newPdf = await PDFDocument.create();
        const arrayBuffer = await fileInput.files[0].arrayBuffer();
        const originalPdf = await PDFDocument.load(arrayBuffer);

        // Copy selected pages in order
        const sortedPages = Array.from(selectedPages).sort((a, b) => a - b);
        for (const pageNum of sortedPages) {
            const [page] = await newPdf.copyPages(originalPdf, [pageNum - 1]);
            newPdf.addPage(page);
        }

        const pdfBytes = await newPdf.save();
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);

        // Set up download
        const downloadBtn = document.getElementById('download-btn');
        downloadBtn.onclick = () => {
            const a = document.createElement('a');
            a.href = url;
            a.download = getDownloadName();
            a.click();
        };
        
        statusEl.textContent = `Ready! ${sortedPages.length} pages selected. Click Download.`;
    } catch (error) {
        statusEl.textContent = "Error splitting PDF: " + error.message;
    }
}

function getDownloadName() {
    const pages = Array.from(selectedPages).sort((a, b) => a - b);
    
    // If continuous range, use "3-5" format
    if (pages.length > 1) {
        let isContinuous = true;
        for (let i = 1; i < pages.length; i++) {
            if (pages[i] !== pages[i-1] + 1) {
                isContinuous = false;
                break;
            }
        }
        
        if (isContinuous) {
            return `pages_${pages[0]}-${pages[pages.length-1]}.pdf`;
        }
    }
    
    return `pages_${pages.join('_')}.pdf`;
}

function downloadSplitPDF() {
    // Handled in splitPDF()
}